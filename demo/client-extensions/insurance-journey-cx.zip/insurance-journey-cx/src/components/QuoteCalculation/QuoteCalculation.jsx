/**
 * QuoteCalculation (Step 3)
 * -------------------------
 * The main quote calculation screen.
 * Receives formData from previous steps for dynamic display.
 */

import React from 'react';
import QuoteHeader from './QuoteHeader';
import ProtectionForm from './ProtectionForm';
import QuoteHero from './QuoteHero';
import PaymentOptions from './PaymentOptions';
import StickyRateSection from './StickyRateSection';
import { useQuote } from '../../hooks';
import { QUOTE_CONFIG } from '../../constants';
import { calculateAge } from '../../utils';
import './QuoteCalculation.css';

function QuoteCalculation({ formData = {}, onProceed }) {
  const { selections, updateSelection } = useQuote();

  // Derive dynamic user info from previous steps
  const age = calculateAge(formData.dateOfBirth);
  const userName = formData.fullName || 'User';
  const userAge = age ? `${age} Yrs` : '';

  const handleProceed = () => {
    // Pass current quote selections back to App for Step 4
    if (onProceed) onProceed(selections);
  };

  return (
    <div className="ij-quote-page">
      <div className="ij-quote-page__container">
        {/* Top Header — dynamic name/age */}
        <QuoteHeader userName={userName} userAge={userAge} />

        <div className="ij-quote-page__content">
          {/* Sidebar */}
          <aside className="ij-quote-page__sidebar">
            <ProtectionForm values={selections} onUpdate={updateSelection} />
            
            {/* Customer Testimonial placeholder matching design */}
            <div className="ij-quote-page__testimonial">
              <div className="ij-quote-page__stars">★★★★★</div>
              <p>"PNB MetLife Products are made keeping safety and utility in mind, making it very helpful to my family."</p>
              <div className="ij-quote-page__user">
                <div className="ij-quote-page__avatar">RK</div>
                <div className="ij-quote-page__user-info">
                  <strong>Roohi Kaushal</strong>
                  <span>PNB MetLife Customer</span>
                </div>
              </div>
            </div>
          </aside>

          {/* Main Area */}
          <main className="ij-quote-page__main">
            <QuoteHero />
            
            <PaymentOptions 
              selectedId={selections.selectedPaymentOption} 
              onSelect={(id) => updateSelection('selectedPaymentOption', id)} 
            />
          </main>
        </div>
      </div>

      {/* Bottom Rate Section */}
      <StickyRateSection onProceed={handleProceed} />
    </div>
  );
}

export default QuoteCalculation;
