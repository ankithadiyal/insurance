export { calculateAge, formatDobDisplay, calculateTillYear, formatGender, formatMobile, buildSummaryData } from './formDataUtils';
